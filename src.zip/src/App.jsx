
import Dashboard from './components/Dashboard'

function App() {
  return (
    <div className="flex min-h-screen bg-[#f4f4f5]">
      <Dashboard />
    </div>
  )
}

export default App
