const Card = ({ title, children }) => (
  <div className="bg-white rounded-xl shadow-md p-4 space-y-2">
    {title && <h2 className="text-gray-700 font-bold text-lg">{title}</h2>}
    {children}
  </div>
)

export default Card
