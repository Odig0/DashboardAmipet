import Navbar from './Navbar'
import Card from './Card'
import PieChart from './PieChart'
import BarChart from './Barchart'

export default function Dashboard() {
  return (
    <>
      {/* Sidebar fijo a la izquierda */}
      <Navbar />

      {/* Contenido expandido a la derecha */}
      <main className="flex-1 px-10 pt-6 grid grid-cols-1 sm:grid-cols-2 gap-6 bg-[#f9fafb] min-h-screen">
        <Card title="Productos disponibles">
          <h1 className="text-4xl font-bold text-center text-gray-800">186</h1>
        </Card>

        <Card title="Productos vendidos hoy">
          <h1 className="text-4xl font-bold text-center text-green-600">47</h1>
        </Card>

        <Card title="Servicios agendados">
          <h1 className="text-4xl font-bold text-center text-blue-600">12</h1>
        </Card>

        <Card title="Ganancias del mes" className="col-span-1 sm:col-span-2 lg:col-span-1">
          <h1 className="text-5xl font-extrabold text-center text-purple-700">Bs. 12.430</h1>
        </Card>

                <div className="col-span-1 sm:col-span-2 flex flex-col lg:flex-row gap-6">
        <Card title="Distribución de inversión" className="w-full lg:w-1/2">
            <PieChart />
        </Card>

        <Card title="Ventas por hora" className="w-full lg:w-1/2">
            <BarChart />
        </Card>
        </div>

      </main>
    </>
  )
}
