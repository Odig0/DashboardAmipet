
const Navbar = () => {
  return (
    <header className="w-full h-20 bg-[#1e1b4b] text-white flex items-center px-10 shadow-md">
      <h1 className="text-2xl font-bold mr-10">AmiPet</h1>
      <nav className="flex gap-6">
        <a className="hover:text-yellow-400 cursor-pointer">Panel</a>
        <a className="hover:text-yellow-400 cursor-pointer">Inventario</a>
        <a className="hover:text-yellow-400 cursor-pointer">Ventas</a>
        <a className="hover:text-yellow-400 cursor-pointer">Servicios</a>
        <a className="hover:text-yellow-400 cursor-pointer">Configuración</a>
      </nav>
    </header>
  );
};

export default Navbar;
